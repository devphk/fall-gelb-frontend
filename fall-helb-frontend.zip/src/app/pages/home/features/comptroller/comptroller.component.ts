import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comptroller',
  templateUrl: './comptroller.component.html',
  styleUrls: ['./comptroller.component.scss']
})
export class ComptrollerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
